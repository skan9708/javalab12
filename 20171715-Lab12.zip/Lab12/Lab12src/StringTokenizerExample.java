import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class StringTokenizerExample {
    public static void main(String[] args) {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String line;
        
        try {
            while (true) {
                System.out.print("Enter a line of text (or 'quit' to exit): ");
                line = in.readLine();
                
                if (line.equalsIgnoreCase("quit")) {
                    System.out.println("Program terminated.");
                    break;
                }
                
                // 출력한 줄 다시 출력
                System.out.println("You entered: " + line);

                // StringTokenizer를 사용하여 단어 수를 세고 각 단어를 출력
                StringTokenizer tokenizer = new StringTokenizer(line);
                int wordCount = tokenizer.countTokens();
                System.out.println("There are " + wordCount + " words in this line.");
                
                while (tokenizer.hasMoreTokens()) {
                    System.out.println(tokenizer.nextToken());
                }
                
                System.out.println(); // 줄 간격을 위한 빈 줄 추가
            }
        } catch (IOException e) {
            System.out.println("An IOException occurred: " + e.getMessage());
        }
    }
}